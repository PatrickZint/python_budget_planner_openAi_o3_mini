import numpy as np

class CelestialBody:
    def __init__(self, identifier, mass, position, velocity):
        if mass <= 0:
            raise ValueError(f"Mass must be positive for body {identifier}")
        if not (isinstance(position, list) or isinstance(position, tuple)) or len(position) != 2:
            raise ValueError(f"Position must be a 2D coordinate for body {identifier}")
        if not (isinstance(velocity, list) or isinstance(velocity, tuple)) or len(velocity) != 2:
            raise ValueError(f"Velocity must be a 2D vector for body {identifier}")

        self.id = identifier
        self.mass = mass
        self.position = np.array(position, dtype=float)
        self.velocity = np.array(velocity, dtype=float)
        # For Verlet integration, we store previous position (initialize as current position)
        self.previous_position = np.array(position, dtype=float)

    def __str__(self):
        return f"CelestialBody(id={self.id}, mass={self.mass}, position={self.position}, velocity={self.velocity})"
