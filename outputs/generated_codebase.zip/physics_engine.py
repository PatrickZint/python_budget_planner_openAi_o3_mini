import math
import pygame
from integrators import get_integrator

class PhysicsEngine:
    def __init__(self, gravitational_constant, integration_method):
        self.G = gravitational_constant
        self.integrator = get_integrator(integration_method)

    def compute_forces(self, bodies):
        # Reset forces
        for body in bodies:
            body.reset_force()
        # Compute pairwise gravitational forces
        n = len(bodies)
        for i in range(n):
            for j in range(i+1, n):
                body1 = bodies[i]
                body2 = bodies[j]
                # Vector from body1 to body2
                diff = body2.position - body1.position
                distance_sq = diff.length_squared()
                # Avoid division by zero / too small distances
                if distance_sq < 1e-4:
                    distance_sq = 1e-4
                force_magnitude = self.G * body1.mass * body2.mass / distance_sq
                force_direction = diff.normalize()
                force = force_direction * force_magnitude
                # Apply equal and opposite forces
                body1.apply_force(force)
                body2.apply_force(-force)

    def update(self, bodies, dt):
        self.integrator.update(bodies, dt, self)
