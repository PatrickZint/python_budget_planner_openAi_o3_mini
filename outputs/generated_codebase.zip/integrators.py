import numpy as np
from copy import deepcopy
from celestial_body import CelestialBody

class BaseIntegrator:
    def update(self, bodies, dt, G):
        """
        Update the state of all celestial bodies over time step dt.
        This is an abstract method that should be implemented by concrete integrators.
        """
        raise NotImplementedError("update() must be implemented by subclasses")

class EulerIntegrator(BaseIntegrator):
    def update(self, bodies, dt, G):
        # Compute accelerations for each body
        accelerations = {body.id: np.zeros(2) for body in bodies}
        for i, body in enumerate(bodies):
            for j, other in enumerate(bodies):
                if i == j:
                    continue
                # Compute vector from body to other
                r_vec = other.position - body.position
                r = np.linalg.norm(r_vec)
                if r > 0:
                    accel = G * other.mass / (r ** 3) * r_vec
                    accelerations[body.id] += accel

        # Update velocities and positions using Euler method
        for body in bodies:
            body.velocity += accelerations[body.id] * dt
            body.position += body.velocity * dt

class VerletIntegrator(BaseIntegrator):
    def update(self, bodies, dt, G):
        # For Verlet, we need to compute new positions using current acceleration
        # and previous positions. We'll compute acceleration similar to Euler.
        new_positions = {}
        accelerations = {body.id: np.zeros(2) for body in bodies}

        for i, body in enumerate(bodies):
            for j, other in enumerate(bodies):
                if i == j:
                    continue
                r_vec = other.position - body.position
                r = np.linalg.norm(r_vec)
                if r > 0:
                    accel = G * other.mass / (r ** 3) * r_vec
                    accelerations[body.id] += accel

        for body in bodies:
            # Verlet formula: x(t+dt) = 2*x(t) - x(t-dt) + a*dt^2
            new_pos = 2 * body.position - body.previous_position + accelerations[body.id] * (dt ** 2)
            # estimate new velocity
            new_vel = (new_pos - body.previous_position) / (2 * dt)
            body.previous_position = deepcopy(body.position)
            body.position = new_pos
            body.velocity = new_vel

class RK4Integrator(BaseIntegrator):
    def update(self, bodies, dt, G):
        # RK4 integration: for the sake of simplicity, we perform a simple RK4 step for each body.
        # Note: In a coupled system like this, a full RK4 requires computing intermediate states for all bodies simultaneously.
        # Here, we provide a simplified version for demonstration.
        new_states = {}
        for body in bodies:
            k1_v = self._acceleration(body, bodies, G)
            k1_x = body.velocity

            # First intermediate step (not fully coupled):
            temp_vel = body.velocity + 0.5 * k1_v * dt
            temp_pos = body.position + 0.5 * k1_x * dt
            k2_v = self._acceleration_temp(body, bodies, G, temp_pos)
            k2_x = temp_vel

            # Second intermediate step
            temp_vel = body.velocity + 0.5 * k2_v * dt
            temp_pos = body.position + 0.5 * k2_x * dt
            k3_v = self._acceleration_temp(body, bodies, G, temp_pos)
            k3_x = temp_vel

            # Third intermediate step
            temp_vel = body.velocity + k3_v * dt
            temp_pos = body.position + k3_x * dt
            k4_v = self._acceleration_temp(body, bodies, G, temp_pos)
            k4_x = temp_vel

            new_vel = body.velocity + (dt / 6.0) * (k1_v + 2*k2_v + 2*k3_v + k4_v)
            new_pos = body.position + (dt / 6.0) * (k1_x + 2*k2_x + 2*k3_x + k4_x)
            new_states[body.id] = (new_pos, new_vel)

        for body in bodies:
            new_pos, new_vel = new_states[body.id]
            body.position = new_pos
            body.velocity = new_vel

    def _acceleration(self, body, bodies, G):
        accel = 0.0 * body.position
        for other in bodies:
            if other.id == body.id:
                continue
            r_vec = other.position - body.position
            r = np.linalg.norm(r_vec)
            if r > 0:
                accel += G * other.mass / (r ** 3) * r_vec
        return accel

    def _acceleration_temp(self, current_body, bodies, G, temp_pos):
        # helper for RK4 when using temporary positions
        accel = 0.0 * temp_pos
        for other in bodies:
            if other.id == current_body.id:
                continue
            # Use the current positions for other bodies (could be improved)
            r_vec = other.position - temp_pos
            r = np.linalg.norm(r_vec)
            if r > 0:
                accel += G * other.mass / (r ** 3) * r_vec
        return accel
