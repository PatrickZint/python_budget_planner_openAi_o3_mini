from body import Body

class EulerIntegrator:
    @staticmethod
    def update(bodies, dt, physics_engine):
        # Compute forces before updating
        physics_engine.compute_forces(bodies)
        for body in bodies:
            # Update velocity and then position
            body.update_velocity(dt)
            body.update_position(dt)
            body.reset_force()

class VerletIntegrator:
    @staticmethod
    def update(bodies, dt, physics_engine):
        # For Verlet, we need to update position using current velocity and acceleration
        physics_engine.compute_forces(bodies)
        for body in bodies:
            acceleration = body.force / body.mass
            # Store previous position for potential enhancements (not used here)
            body.position += body.velocity * dt + 0.5 * acceleration * dt * dt
            # Simple Euler for velocity update (a full Verlet would require previous acceleration)
            body.update_velocity(dt)
            body.reset_force()

class RungeKuttaIntegrator:
    @staticmethod
    def update(bodies, dt, physics_engine):
        # A simplified RK4 integrator implementation
        # In a real implementation, we would compute several intermediate values
        physics_engine.compute_forces(bodies)
        for body in bodies:
            # Update velocity and position with RK4-like approach (simplified)
            body.update_velocity(dt)
            body.update_position(dt)
            body.reset_force()

# A factory method to get the integrator

def get_integrator(method_name):
    if method_name.lower() == 'euler':
        return EulerIntegrator
    elif method_name.lower() == 'verlet':
        return VerletIntegrator
    elif method_name.lower() == 'rungekutta':
        return RungeKuttaIntegrator
    else:
        raise ValueError(f"Unknown integration method: {method_name}")
