from vpython import sphere, vector, rate, scene, color


class VPythonRenderer:
    def __init__(self, simulation_controller, config):
        self.simulation = simulation_controller
        self.bodies_visual = []
        self.init_scene()
        self.create_body_visuals()

    def init_scene(self):
        scene.title = "3D Gravitational Simulation"
        scene.width = 800
        scene.height = 600
        scene.background = color.black

    def create_body_visuals(self):
        """Create visual representations for each simulation body."""
        self.bodies_visual = []
        for body in self.simulation.bodies:
            s = sphere(pos=vector(*body.position), radius=body.radius, make_trail=True)
            self.bodies_visual.append(s)

    def update(self):
        rate(100)  # Control the refresh rate for smooth animation
        # Update positions of visual objects to match simulation bodies
        for i, body in enumerate(self.simulation.bodies):
            try:
                self.bodies_visual[i].pos = vector(*body.position)
            except IndexError:
                # If new bodies are added during simulation, create their visuals
                from vpython import sphere
                s = sphere(pos=vector(*body.position), radius=body.radius, make_trail=True)
                self.bodies_visual.append(s)
