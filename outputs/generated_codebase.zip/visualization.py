import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

class PlotManager:
    def __init__(self, simulation_data):
        self.simulation_data = simulation_data
        self.body1_positions = [state['body1']['pos'] for state in simulation_data]
        self.body2_positions = [state['body2']['pos'] for state in simulation_data]
        self.fig, self.ax = plt.subplots()
        self.body1_line, = self.ax.plot([], [], 'bo-', label='Body 1')
        self.body2_line, = self.ax.plot([], [], 'ro-', label='Body 2')

    def init_plot(self):
        self.ax.set_xlabel('X Position')
        self.ax.set_ylabel('Y Position')
        self.ax.set_title('2D Orbital Simulator Trajectories')
        self.ax.legend()
        self.ax.grid(True)
        return self.body1_line, self.body2_line

    def update(self, frame):
        # Update the plot for the given frame
        b1_pos = self.body1_positions[:frame+1]
        b2_pos = self.body2_positions[:frame+1]

        b1_x = [pos[0] for pos in b1_pos]
        b1_y = [pos[1] for pos in b1_pos]
        b2_x = [pos[0] for pos in b2_pos]
        b2_y = [pos[1] for pos in b2_pos]

        self.body1_line.set_data(b1_x, b1_y)
        self.body2_line.set_data(b2_x, b2_y)

        # Optionally, adjust plot limits dynamically
        all_x = b1_x + b2_x
        all_y = b1_y + b2_y
        if all_x and all_y:
            self.ax.set_xlim(min(all_x)-1, max(all_x)+1)
            self.ax.set_ylim(min(all_y)-1, max(all_y)+1)

        return self.body1_line, self.body2_line

    def show_static(self):
        # Create a static plot of the full trajectories
        b1_x = [pos[0] for pos in self.body1_positions]
        b1_y = [pos[1] for pos in self.body1_positions]
        b2_x = [pos[0] for pos in self.body2_positions]
        b2_y = [pos[1] for pos in self.body2_positions]

        plt.figure()
        plt.plot(b1_x, b1_y, 'bo-', label='Body 1')
        plt.plot(b2_x, b2_y, 'ro-', label='Body 2')
        plt.xlabel('X Position')
        plt.ylabel('Y Position')
        plt.title('2D Orbital Simulator Trajectories')
        plt.legend()
        plt.grid(True)
        plt.show()

    def animate(self, interval=50):
        # Animate the simulation using matplotlib's FuncAnimation
        anim = FuncAnimation(self.fig, self.update, init_func=self.init_plot,
                             frames=len(self.simulation_data), interval=interval, blit=True, repeat=False)
        plt.show()
