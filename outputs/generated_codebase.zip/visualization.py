import matplotlib.pyplot as plt
import matplotlib.animation as animation


class Visualizer:
    def __init__(self):
        self.fig, self.ax = plt.subplots()
        self.scat = None
        self.bodies_positions = []
        self.ani = None
        self.initialized = False

    def init_visualization(self, bodies):
        # Extract initial positions
        self.bodies_positions = [body.position for body in bodies]
        x = [pos[0] for pos in self.bodies_positions]
        y = [pos[1] for pos in self.bodies_positions]

        self.scat = self.ax.scatter(x, y, c='blue')
        self.ax.set_title('2D Orbital Simulator')
        self.ax.set_xlabel('X Position')
        self.ax.set_ylabel('Y Position')
        self.initialized = True
        plt.ion()
        plt.show()

    def update_plot(self, bodies):
        if not self.initialized:
            return
        # Update positions
        self.bodies_positions = [body.position for body in bodies]
        x = [pos[0] for pos in self.bodies_positions]
        y = [pos[1] for pos in self.bodies_positions]
        self.scat.set_offsets(list(zip(x, y)))
        self.ax.relim()
        self.ax.autoscale_view()
        plt.pause(0.001)

    def render_final_plot(self):
        # Turn off interactive mode and display the final plot
        plt.ioff()
        plt.show()
