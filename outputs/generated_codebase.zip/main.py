import sys
import argparse
import logging
from config_manager import ConfigManager
from celestial_body import CelestialBody
from integrators import EulerIntegrator, VerletIntegrator, RK4Integrator
from simulation_engine import SimulationEngine
from ui import SimulationUI
import threading


def parse_arguments():
    parser = argparse.ArgumentParser(description='2D N-Body Simulation')
    parser.add_argument('--config', type=str, default='config.json', help='Path to the configuration JSON file')
    return parser.parse_args()


def create_bodies(bodies_config):
    bodies = []
    for body_conf in bodies_config:
        body = CelestialBody(
            identifier=body_conf['id'],
            mass=body_conf['mass'],
            position=body_conf['position'],
            velocity=body_conf['velocity']
        )
        bodies.append(body)
    return bodies


def select_integrator(integrator_name):
    if integrator_name.lower() == 'euler':
        return EulerIntegrator()
    elif integrator_name.lower() == 'verlet':
        return VerletIntegrator()
    elif integrator_name.lower() == 'rk4':
        return RK4Integrator()
    else:
        raise ValueError(f"Unknown integrator: {integrator_name}")


def main():
    args = parse_arguments()
    try:
        config = ConfigManager.load_configuration(args.config)
    except Exception as e:
        logging.error(f"Failed to load configuration: {str(e)}")
        sys.exit(1)

    global_params = config['global_parameters']
    G = global_params['gravitational_constant']
    dt = global_params['time_step']
    integrator_name = global_params['integrator']

    bodies = create_bodies(config['bodies'])

    integrator = select_integrator(integrator_name)
    engine = SimulationEngine(bodies, G, dt, integrator)

    # Start the simulation in a separate thread
    engine.start_simulation()

    # Start the UI (this will block until the plot window is closed)
    ui = SimulationUI(engine)
    try:
        ui.run()
    except KeyboardInterrupt:
        pass
    finally:
        engine.stop()

if __name__ == '__main__':
    main()
