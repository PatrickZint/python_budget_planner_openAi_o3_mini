import numpy as np
from simulation_engine import SimulationEngine
from data_io import get_command_line_args, parse_config_file, setup_logger, export_data_csv, export_data_json
from visualization import PlotManager


def main():
    # Parse command-line arguments
    args = get_command_line_args()
    verbosity = 10 if args.verbose else 20  # 10=DEBUG, 20=INFO
    logger = setup_logger(verbosity)
    
    logger.info('Loading configuration...')
    config = parse_config_file(args.config)

    # Extract simulation parameters from config
    dt = config.get('time_step', 1.0)
    duration = config.get('duration', 100.0)

    # Define bodies using configuration; defaults provided if missing
    body1 = config.get('body1', {
        'pos': [0.0, 0.0],
        'vel': [0.0, 0.0],
        'mass': 5.972e24  # Earth mass in kg as an example
    })
    body2 = config.get('body2', {
        'pos': [1.0e7, 0.0],
        'vel': [0.0, 1000.0],
        'mass': 7.348e22  # Moon mass in kg as an example
    })

    # Optionally set gravitational constant if provided
    G = config.get('G', 6.67430e-11)

    logger.info('Initializing simulation engine...')
    simulator = SimulationEngine(body1, body2, dt, duration, G=G)

    logger.info('Running simulation...')
    simulation_data = simulator.run()
    logger.info(f'Simulation completed with {len(simulation_data)} time steps.')

    if args.export_csv:
        logger.info(f'Exporting simulation data to CSV: {args.export_csv}')
        export_data_csv(args.export_csv, simulation_data)
    if args.export_json:
        logger.info(f'Exporting simulation data to JSON: {args.export_json}')
        export_data_json(args.export_json, simulation_data)

    if args.visualize:
        logger.info('Launching visualization...')
        plot_manager = PlotManager(simulation_data)
        # For demonstration, you can switch between static and animated display
        # Uncomment one of the following lines:
        # plot_manager.show_static()
        plot_manager.animate()

if __name__ == '__main__':
    main()
