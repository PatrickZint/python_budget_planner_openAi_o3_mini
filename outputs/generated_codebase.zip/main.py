import sys
import pygame
from config_manager import ConfigManager
from logger_config import setup_logger
from simulation_manager import SimulationManager
from display_manager import DisplayManager
from input_handler import InputHandler


def main():
    # Load configuration
    config_manager = ConfigManager()
    config = config_manager.config

    # Setup logging
    logger = setup_logger(config)
    logger.info("Starting 2D Newtonian N-body Simulation")

    # Initialize simulation manager
    sim_manager = SimulationManager(config, logger)
    # Pass config into simulation_manager as an attribute for resetting purposes
    sim_manager.config = config

    # Initialize display manager
    display = DisplayManager(config, logger)

    # Initialize input handler
    input_handler = InputHandler(sim_manager, logger)

    # Main loop
    running = True
    while running:
        # Input handling
        command = input_handler.process_events()
        if command == 'QUIT':
            running = False
            continue

        # Update simulation
        sim_manager.update()

        # Render simulation state
        extra_info = [f"Time: {sim_manager.elapsed_time:.2f}", 
                      f"Bodies: {len(sim_manager.bodies)}", 
                      f"Paused: {sim_manager.paused}"]
        display.render(sim_manager.bodies, extra_info)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
