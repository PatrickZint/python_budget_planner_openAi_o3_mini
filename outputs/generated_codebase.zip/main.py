import sys
import time
import argparse
import numpy as np

from config import parse_args, load_config, validate_parameters
from physics import CelestialBody, update_positions
from data_logger import DataLogger
from visualization import Visualizer


def initialize_bodies(config):
    # For simplicity, assume config contains a list of bodies
    bodies = []
    for body_conf in config.get('bodies', []):
        body = CelestialBody(
            mass=body_conf['mass'],
            position=np.array(body_conf['position'], dtype=float),
            velocity=np.array(body_conf['velocity'], dtype=float)
        )
        bodies.append(body)
    return bodies


def main():
    # Parse command-line arguments
    args = parse_args()

    # Load configuration from file if provided
    if args.config:
        config = load_config(args.config)
    else:
        # Use command-line parameters to build a basic configuration
        config = {
            "dt": args.dt,
            "simulation_time": args.simulation_time,
            "G": args.G,
            "integration_method": args.integration_method,
            "logging_frequency": args.logging_frequency,
            "visualization": args.visualization,
            "bodies": [
                {
                    "mass": 5.972e24,
                    "position": [0, 0],
                    "velocity": [0, 0]
                },
                {
                    "mass": 7.348e22,
                    "position": [384400000, 0],
                    "velocity": [0, 1022]
                }
            ]
        }

    # Validate configuration parameters
    try:
        validate_parameters(config)
    except ValueError as ve:
        sys.exit(f"Configuration error: {ve}")

    dt = config.get('dt', 1)
    simulation_time = config.get('simulation_time', 1000)
    G = config.get('G', 6.67430e-11)
    logging_frequency = config.get('logging_frequency', 1)
    enable_viz = config.get('visualization', False)
    integration_method = config.get('integration_method', 'euler')

    # Initialize simulation components
    bodies = initialize_bodies(config)
    logger = DataLogger(logging_frequency=logging_frequency, output_file='simulation_log.csv')
    visualizer = None
    if enable_viz:
        visualizer = Visualizer()
        visualizer.init_visualization(bodies)

    current_time = 0.0
    step = 0

    print('Starting simulation...')
    try:
        while current_time < simulation_time:
            # Update physics (Euler's method by default)
            update_positions(bodies, dt, G, method=integration_method)

            # Log state every logging_frequency steps
            if step % logging_frequency == 0:
                state = []
                for body in bodies:
                    state.append({
                        'mass': body.mass,
                        'position': body.position.tolist(),
                        'velocity': body.velocity.tolist()
                    })
                logger.log_simulation_state(current_time, state)

            # Update visualization if enabled
            if enable_viz and visualizer is not None:
                visualizer.update_plot(bodies)

            current_time += dt
            step += 1
            time.sleep(0.01)  # small sleep to simulate real-time progression

    except KeyboardInterrupt:
        print('\nSimulation interrupted by user.')
    finally:
        if enable_viz and visualizer is not None:
            visualizer.render_final_plot()
        print('Simulation finished.')


if __name__ == '__main__':
    main()
