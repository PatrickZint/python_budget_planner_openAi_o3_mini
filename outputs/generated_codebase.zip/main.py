import time
from simulation_engine import SimulationController
from visualization import VPythonRenderer
from exporter import DataExporter
from security import load_secure_config


def main():
    # Load secure configuration from environment variables or a .env file
    config = load_secure_config()

    # Initialize the simulation controller with physics, collision, and event management
    simulation = SimulationController(config)

    # Initialize the VPython renderer for interactive 3D visualization
    renderer = VPythonRenderer(simulation, config)

    # Initialize the data exporter for logging and data export (CSV and HDF5)
    exporter = DataExporter(config)

    print('Starting simulation...')
    try:
        while simulation.running:
            # Update the simulation state by one tick
            simulation.update()
            
            # Refresh the VPython scene
            renderer.update()
            
            # Log the simulation state periodically
            exporter.log(simulation)
            
            # Pause according to time step for real-time simulation
            time.sleep(config['time_step'])
    except KeyboardInterrupt:
        print('Simulation terminated by user.')
        simulation.running = False
    finally:
        # On shutdown, export logged data
        exporter.export(simulation)
        print('Data export complete. Shutting down.')


if __name__ == '__main__':
    main()