import pygame

class Body:
    def __init__(self, mass, position, velocity, radius=5, color=(255, 255, 255)):
        self.mass = mass
        self.position = pygame.math.Vector2(position)
        self.velocity = pygame.math.Vector2(velocity)
        self.force = pygame.math.Vector2(0, 0)
        self.radius = radius
        self.color = color

    def update_position(self, dt):
        self.position += self.velocity * dt

    def update_velocity(self, dt):
        # acceleration = force / mass
        acceleration = self.force / self.mass
        self.velocity += acceleration * dt

    def reset_force(self):
        self.force = pygame.math.Vector2(0, 0)

    def apply_force(self, force):
        self.force += force
