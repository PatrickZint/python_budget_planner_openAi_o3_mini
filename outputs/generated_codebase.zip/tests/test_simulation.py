import numpy as np
import pytest
from celestial_body import CelestialBody
from integrators import EulerIntegrator, VerletIntegrator, RK4Integrator

# Test CelestialBody validation

def test_celestial_body_positive_mass():
    with pytest.raises(ValueError):
        CelestialBody('body1', 0, [0, 0], [0, 0])
    with pytest.raises(ValueError):
        CelestialBody('body2', -5, [0, 0], [0, 0])


def test_celestial_body_position_length():
    with pytest.raises(ValueError):
        CelestialBody('body3', 5, [0], [0, 0])
    with pytest.raises(ValueError):
        CelestialBody('body4', 5, [0, 0, 0], [0, 0])


def test_euler_integrator_updates():
    # Create two bodies and test that positions/velocities are updated
    body1 = CelestialBody('1', 10, [0, 0], [0, 0])
    body2 = CelestialBody('2', 20, [1, 0], [0, 0])
    bodies = [body1, body2]
    integrator = EulerIntegrator()
    dt = 0.1
    G = 1.0
    pos1_old = body1.position.copy()
    integrator.update(bodies, dt, G)
    # Check that at least one of the positions has changed
    assert not np.array_equal(pos1_old, body1.position)


def test_verlet_integrator_updates():
    body1 = CelestialBody('1', 10, [0, 0], [0, 0])
    body2 = CelestialBody('2', 20, [1, 0], [0, 0])
    bodies = [body1, body2]
    integrator = VerletIntegrator()
    dt = 0.1
    G = 1.0
    pos1_old = body1.position.copy()
    integrator.update(bodies, dt, G)
    assert not np.array_equal(pos1_old, body1.position)


def test_rk4_integrator_updates():
    body1 = CelestialBody('1', 10, [0, 0], [0, 0])
    body2 = CelestialBody('2', 20, [1, 0], [0, 0])
    bodies = [body1, body2]
    integrator = RK4Integrator()
    dt = 0.1
    G = 1.0
    pos1_old = body1.position.copy()
    integrator.update(bodies, dt, G)
    assert not np.array_equal(pos1_old, body1.position)
