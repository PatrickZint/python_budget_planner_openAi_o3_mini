import json
import jsonschema
from jsonschema import validate
import logging

# Define the JSON schema for configuration validation
CONFIG_SCHEMA = {
    "type": "object",
    "properties": {
        "version": {"type": "string"},
        "global_parameters": {
            "type": "object",
            "properties": {
                "gravitational_constant": {"type": "number"},
                "time_step": {"type": "number"},
                "integrator": {"type": "string", "enum": ["euler", "verlet", "rk4"]}
            },
            "required": ["gravitational_constant", "time_step", "integrator"]
        },
        "bodies": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "mass": {"type": "number", "exclusiveMinimum": 0},
                    "position": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2
                    },
                    "velocity": {
                        "type": "array",
                        "items": {"type": "number"},
                        "minItems": 2,
                        "maxItems": 2
                    }
                },
                "required": ["id", "mass", "position", "velocity"]
            }
        }
    },
    "required": ["version", "global_parameters", "bodies"]
}

class ConfigManager:
    @staticmethod
    def load_configuration(file_path):
        """
        Loads and validates the simulation configuration from a JSON file.
        """
        try:
            with open(file_path, 'r') as f:
                config = json.load(f)
            # Validate the configuration against the schema
            validate(instance=config, schema=CONFIG_SCHEMA)
            logging.info(f"Configuration loaded and validated from {file_path}")
            return config
        except jsonschema.exceptions.ValidationError as ve:
            logging.error(f"Configuration validation error: {ve.message}")
            raise
        except Exception as e:
            logging.error(f"Error loading configuration: {str(e)}")
            raise

    @staticmethod
    def save_configuration(config, file_path):
        """
        Saves a simulation configuration to a JSON file.
        """
        try:
            with open(file_path, 'w') as f:
                json.dump(config, f, indent=4)
            logging.info(f"Configuration saved to {file_path}")
        except Exception as e:
            logging.error(f"Error saving configuration: {str(e)}")
            raise
