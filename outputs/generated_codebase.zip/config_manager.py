import json
import os

class ConfigManager:
    DEFAULT_CONFIG = {
        "gravitational_constant": 6.67430e-11,
        "time_step": 0.1,
        "integration_method": "Euler",  # Options: Euler, Verlet, RungeKutta
        "initial_bodies": [
            {"mass": 1e5, "position": [300, 300], "velocity": [0, 0]},
            {"mass": 1e5, "position": [500, 300], "velocity": [0, 0]}
        ],
        "logging": {
            "level": "DEBUG",
            "console": true,
            "file": "simulation.log"
        },
        "display": {
            "width": 800,
            "height": 600,
            "fps": 60
        }
    }

    def __init__(self, config_file='config.json'):
        self.config_file = config_file
        self.config = self.load_config()

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                # Validate mandatory fields here if needed
                return config
            except Exception as e:
                print(f"Error reading config: {e}. Falling back to default configuration.")
        else:
            print("Config file not found. Using default configuration.")
        return self.DEFAULT_CONFIG

    def get(self, key, default=None):
        return self.config.get(key, default)
