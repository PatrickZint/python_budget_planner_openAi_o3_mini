import pygame

class DisplayManager:
    def __init__(self, config, logger):
        pygame.init()
        display_conf = config.get('display', {})
        self.width = display_conf.get('width', 800)
        self.height = display_conf.get('height', 600)
        self.fps = display_conf.get('fps', 60)
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption('2D Newtonian N-body Simulation')
        self.clock = pygame.time.Clock()
        self.logger = logger
        self.font = pygame.font.SysFont('Arial', 16)

    def render(self, bodies, extra_info=None):
        self.screen.fill((0, 0, 0))
        # Draw bodies
        for body in bodies:
            pos = (int(body.position.x), int(body.position.y))
            pygame.draw.circle(self.screen, body.color, pos, body.radius)
        
        # Render extra_info overlay if provided
        if extra_info:
            y = 10
            for text in extra_info:
                text_surface = self.font.render(text, True, (255, 255, 255))
                self.screen.blit(text_surface, (10, y))
                y += 20
        pygame.display.flip()
        self.clock.tick(self.fps)

    def get_clock(self):
        return self.clock

    def quit(self):
        pygame.quit()
