import csv
import h5py
import time


class DataExporter:
    def __init__(self, config):
        self.config = config
        self.log_interval = config.get('log_interval', 0.1)
        self.last_log_time = time.time()
        # Data will be stored as a list of snapshots
        # Each snapshot contains the simulation time and body states
        self.data = []

    def log(self, simulation):
        current_time = time.time()
        if current_time - self.last_log_time >= self.log_interval:
            snapshot = {
                'time': simulation.current_time,
                # For each body, store position and velocity as lists
                'bodies': [
                    (body.position.tolist(), body.velocity.tolist()) for body in simulation.bodies
                ]
            }
            self.data.append(snapshot)
            self.last_log_time = current_time

    def export(self, simulation):
        # Export logged data to CSV
        csv_filename = self.config.get('export_csv', 'simulation.csv')
        with open(csv_filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['time', 'body_index', 'position', 'velocity'])
            for snapshot in self.data:
                t = snapshot['time']
                for idx, (pos, vel) in enumerate(snapshot['bodies']):
                    writer.writerow([t, idx, pos, vel])

        # Export logged data to HDF5
        hdf5_filename = self.config.get('export_hdf5', 'simulation.h5')
        with h5py.File(hdf5_filename, 'w') as h5file:
            grp = h5file.create_group('simulation')
            times = [snapshot['time'] for snapshot in self.data]
            grp.create_dataset('time', data=times)

            if self.data and self.data[0]['bodies']:
                num_snapshots = len(self.data)
                num_bodies = len(self.data[0]['bodies'])

                # Create datasets for positions and velocities
                pos_data = []
                vel_data = []
                for snapshot in self.data:
                    pos_snapshot = [pos for pos, _ in snapshot['bodies']]
                    vel_snapshot = [vel for _, vel in snapshot['bodies']]
                    pos_data.append(pos_snapshot)
                    vel_data.append(vel_snapshot)

                grp.create_dataset('positions', data=pos_data)
                grp.create_dataset('velocities', data=vel_data)
