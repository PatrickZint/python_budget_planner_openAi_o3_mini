import pygame
from body import Body
from physics_engine import PhysicsEngine

class SimulationManager:
    def __init__(self, config, logger):
        self.logger = logger
        self.dt = config.get('time_step', 0.1)
        self.bodies = []
        self.running = True
        self.paused = False
        self.elapsed_time = 0.0

        # Initialize physics engine
        G = config.get('gravitational_constant', 6.67430e-11)
        integration_method = config.get('integration_method', 'Euler')
        self.physics_engine = PhysicsEngine(G, integration_method)

        # Initialize bodies from config
        for body_conf in config.get('initial_bodies', []):
            body = Body(
                mass=body_conf.get('mass'),
                position=body_conf.get('position'),
                velocity=body_conf.get('velocity')
            )
            self.bodies.append(body)
        self.logger.debug(f"Initialized {len(self.bodies)} bodies.")

    def toggle_pause(self):
        self.paused = not self.paused
        self.logger.info(f"Simulation paused: {self.paused}")

    def reset(self, config):
        # Reinitialize bodies from config
        self.bodies = []
        for body_conf in config.get('initial_bodies', []):
            body = Body(
                mass=body_conf.get('mass'),
                position=body_conf.get('position'),
                velocity=body_conf.get('velocity')
            )
            self.bodies.append(body)
        self.elapsed_time = 0.0
        self.logger.info("Simulation reset to initial conditions.")

    def update(self):
        if not self.paused:
            self.physics_engine.update(self.bodies, self.dt)
            self.elapsed_time += self.dt
            # Log current state
            for i, body in enumerate(self.bodies):
                self.logger.debug(f"Time: {self.elapsed_time:.2f} Body {i}: Pos={body.position}, Vel={body.velocity}, Force={body.force}")
