import logging
import sys

def setup_logger(config):
    log_config = config.get('logging', {})
    log_level = getattr(logging, log_config.get('level', 'DEBUG').upper(), logging.DEBUG)
    logger = logging.getLogger('nbody_simulation')
    logger.setLevel(log_level)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # Console handler
    if log_config.get('console', True):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(log_level)
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    # File handler
    log_file = log_config.get('file')
    if log_file:
        fh = logging.FileHandler(log_file)
        fh.setLevel(log_level)
        fh.setFormatter(formatter)
        logger.addHandler(fh)

    return logger
