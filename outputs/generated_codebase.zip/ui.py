import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import logging

class SimulationUI:
    def __init__(self, simulation_engine):
        self.engine = simulation_engine
        self.fig, self.ax = plt.subplots()
        self.scat = self.ax.scatter([], [])
        self.ax.set_title('2D N-Body Simulation')
        self.ax.set_xlabel('X Position')
        self.ax.set_ylabel('Y Position')

    def init_plot(self):
        self.scat.set_offsets([])
        return self.scat,

    def update_display(self, bodies):
        positions = [body.position for body in bodies]
        # Set plot limits based on positions or define static limits
        positions_array = []
        for pos in positions:
            positions_array.append([pos[0], pos[1]])
        self.scat.set_offsets(positions_array)
        return self.scat,

    def run(self):
        # Use matplotlib animation to update the plot in realtime
        ani = animation.FuncAnimation(self.fig,
                                      self.update_display, 
                                      fargs=(self.engine.bodies,),
                                      init_func=self.init_plot,
                                      interval=50,
                                      blit=True)
        plt.show()
