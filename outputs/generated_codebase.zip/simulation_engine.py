import numpy as np
import warnings

# Gravitational constant
G_DEFAULT = 6.67430e-11

class PhysicsCalculator:
    @staticmethod
    def compute_gravitational_force(pos1, pos2, m1, m2, G=G_DEFAULT):
        # Compute vector from pos1 to pos2
        r_vector = pos2 - pos1
        distance = np.linalg.norm(r_vector) + 1e-12  # add small value to avoid div by zero
        force_magnitude = G * m1 * m2 / (distance ** 2)
        force_vector = force_magnitude * (r_vector / distance)
        return force_vector

class EulerIntegrator:
    def integrate(self, pos, vel, acc, dt):
        # Update velocity and position using simple Euler integration
        new_vel = vel + acc * dt
        new_pos = pos + new_vel * dt
        return new_pos, new_vel

class SimulationEngine:
    def __init__(self, body1, body2, dt, duration, integrator=None, G=G_DEFAULT, instability_threshold=1e12):
        """
        body1 and body2 are dictionaries with keys: 'pos' (numpy array of shape (2,)),
        'vel' (numpy array of shape (2,)) and 'mass' (float).
        dt: time step size
        duration: total simulation time
        integrator: an integrator object with an integrate method (default: EulerIntegrator)
        G: gravitational constant
        instability_threshold: threshold for warning on diverging simulation values
        """
        self.body1 = body1
        self.body2 = body2
        self.dt = dt
        self.duration = duration
        self.integrator = integrator if integrator is not None else EulerIntegrator()
        self.G = G
        self.instability_threshold = instability_threshold
        self.calculator = PhysicsCalculator()
        self.time_steps = int(duration / dt)

    def run(self):
        """
        Runs the simulation and returns a list of state dictionaries for each time step.
        Each state dictionary contains time, positions, velocities and the force computed.
        """
        simulation_data = []
        pos1 = np.array(self.body1['pos'], dtype=float)
        pos2 = np.array(self.body2['pos'], dtype=float)
        vel1 = np.array(self.body1['vel'], dtype=float)
        vel2 = np.array(self.body2['vel'], dtype=float)
        m1 = self.body1['mass']
        m2 = self.body2['mass']

        for step in range(self.time_steps):
            t = step * self.dt
            # Calculate force on body1 due to body2
            force_on_1 = self.calculator.compute_gravitational_force(pos1, pos2, m1, m2, self.G)
            # Newton's Third Law: force on body2 is -force_on_1
            force_on_2 = -force_on_1

            # Compute accelerations
            acc1 = force_on_1 / m1
            acc2 = force_on_2 / m2

            # Update state using Euler integrator
            new_pos1, new_vel1 = self.integrator.integrate(pos1, vel1, acc1, self.dt)
            new_pos2, new_vel2 = self.integrator.integrate(pos2, vel2, acc2, self.dt)

            # Collect state data
            state = {
                'time': t,
                'body1': {
                    'pos': pos1.tolist(),
                    'vel': vel1.tolist(),
                    'acc': acc1.tolist(),
                    'force': force_on_1.tolist()
                },
                'body2': {
                    'pos': pos2.tolist(),
                    'vel': vel2.tolist(),
                    'acc': acc2.tolist(),
                    'force': force_on_2.tolist()
                }
            }
            simulation_data.append(state)

            # Update positions and velocities for next iteration
            pos1, vel1 = new_pos1, new_vel1
            pos2, vel2 = new_pos2, new_vel2

            # Check for instability (e.g., diverging velocities or positions)
            if np.any(np.abs(pos1) > self.instability_threshold) or np.any(np.abs(pos2) > self.instability_threshold):
                warnings.warn(f"Simulation unstable at time {t:.3f}s: positions exceed threshold.")
                break

        return simulation_data
