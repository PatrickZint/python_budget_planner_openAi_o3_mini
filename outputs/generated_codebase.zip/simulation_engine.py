import time
import threading
import logging

class SimulationEngine:
    def __init__(self, bodies, gravitational_constant, time_step, integrator):
        self.bodies = bodies
        self.G = gravitational_constant
        self.dt = time_step
        self.integrator = integrator
        self.running = False
        self.paused = False
        self._lock = threading.Lock()

    def start_simulation(self, update_callback=None):
        """
        Start the simulation loop in a separate thread.
        If update_callback is provided, it will be called after each simulation step
        with the current state of bodies.
        """
        self.running = True
        simulation_thread = threading.Thread(target=self._run, args=(update_callback,))
        simulation_thread.daemon = True
        simulation_thread.start()

    def _run(self, update_callback):
        while self.running:
            with self._lock:
                if not self.paused:
                    # Update simulation state using the integrator
                    self.integrator.update(self.bodies, self.dt, self.G)
                    if update_callback:
                        update_callback(self.bodies)
            time.sleep(self.dt)

    def pause(self):
        with self._lock:
            self.paused = True
            logging.info("Simulation paused.")

    def resume(self):
        with self._lock:
            self.paused = False
            logging.info("Simulation resumed.")

    def set_time_step(self, time_step):
        with self._lock:
            self.dt = time_step
            logging.info(f"Time step updated to {time_step}")

    def stop(self):
        self.running = False
        logging.info("Simulation stopped.")
