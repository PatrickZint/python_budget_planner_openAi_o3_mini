import numpy as np
from physics import Body, integrate_rk4, integrate_verlet
from collision import CollisionManager


class SimulationController:
    def __init__(self, config):
        self.config = config
        self.time_step = config.get('time_step', 0.01)
        self.total_time = config.get('total_time', 10)
        self.method = config.get('integration_method', 'RK4')
        self.bodies = self.initialize_bodies(config)
        self.collision_manager = CollisionManager(config)
        self.current_time = 0
        self.running = True

    def initialize_bodies(self, config):
        # In a full implementation, bodies could be configured via a UI or config file.
        # Here, we create two sample celestial bodies with preset properties.
        bodies = []
        body1 = Body(
            mass=5.0,
            radius=1.0,
            position=np.array([0.0, 0.0, 0.0]),
            velocity=np.array([0.0, 0.0, 0.0])
        )
        body2 = Body(
            mass=1.0,
            radius=0.5,
            position=np.array([5.0, 0.0, 0.0]),
            velocity=np.array([0.0, 1.0, 0.0])
        )
        bodies.append(body1)
        bodies.append(body2)
        return bodies

    def update(self):
        # Update simulation state by one tick
        if self.current_time >= self.total_time:
            self.running = False
            return

        # Select the numerical integration method based on configuration
        if self.method.upper() == 'RK4':
            integrate_rk4(self.bodies, self.time_step)
        else:
            integrate_verlet(self.bodies, self.time_step)

        # Check for collisions and resolve using the collision manager
        self.collision_manager.check_and_resolve(self.bodies)

        self.current_time += self.time_step
