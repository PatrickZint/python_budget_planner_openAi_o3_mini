import numpy as np


class CollisionManager:
    def __init__(self, config):
        # Collision resolution mode: 'merge' or 'bounce'
        self.mode = config.get('collision_mode', 'merge')

    def check_and_resolve(self, bodies):
        """Detect and process collisions among bodies. Uses simple pairwise checks; in production, spatial partitioning should be applied."""
        to_remove = []
        to_add = []
        num_bodies = len(bodies)

        for i in range(num_bodies):
            for j in range(i + 1, num_bodies):
                body1 = bodies[i]
                body2 = bodies[j]
                distance = np.linalg.norm(body1.position - body2.position)
                if distance < (body1.radius + body2.radius):
                    if self.mode.lower() == 'merge':
                        merged_body = self.merge_bodies(body1, body2)
                        to_remove.extend([i, j])
                        to_add.append(merged_body)
                    elif self.mode.lower() == 'bounce':
                        self.bounce_bodies(body1, body2)

        # Remove collided bodies and add merged ones
        if to_remove:
            # Remove duplicate indices by converting to a set
            for index in sorted(set(to_remove), reverse=True):
                del bodies[index]
            bodies.extend(to_add)

    def merge_bodies(self, body1, body2):
        """Merge two bodies conserving total mass and momentum."""
        new_mass = body1.mass + body2.mass
        new_radius = max(body1.radius, body2.radius)  # Simplistic approach
        new_position = (body1.position * body1.mass + body2.position * body2.mass) / new_mass
        new_velocity = (body1.velocity * body1.mass + body2.velocity * body2.mass) / new_mass
        # Import Body locally to avoid circular dependency issues
        from physics import Body
        return Body(new_mass, new_radius, new_position, new_velocity)

    def bounce_bodies(self, body1, body2):
        """Process elastic collision between two bodies using a simple impulse-based model."""
        normal = body2.position - body1.position
        norm = np.linalg.norm(normal) + 1e-10
        normal = normal / norm
        relative_velocity = body1.velocity - body2.velocity
        # Coefficient of restitution (1.0 for perfectly elastic collisions)
        restitution = 1.0
        impulse = -(1 + restitution) * np.dot(relative_velocity, normal) / (1/body1.mass + 1/body2.mass)
        body1.velocity += (impulse * normal) / body1.mass
        body2.velocity -= (impulse * normal) / body2.mass
