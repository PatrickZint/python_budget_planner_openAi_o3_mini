import argparse
import json


def parse_args():
    parser = argparse.ArgumentParser(description='2D Orbital Simulator')
    parser.add_argument('--config', type=str, help='Path to configuration file (JSON)')
    parser.add_argument('--dt', type=float, default=1.0, help='Time step for simulation')
    parser.add_argument('--simulation_time', type=float, default=1000, help='Total simulation time')
    parser.add_argument('--G', type=float, default=6.67430e-11, help='Gravitational constant')
    parser.add_argument('--integration_method', type=str, default='euler', help='Integration method to use')
    parser.add_argument('--logging_frequency', type=int, default=1, help='Frequency (in steps) for logging data')
    parser.add_argument('--visualization', action='store_true', help='Enable visualization')
    return parser.parse_args()


def load_config(filepath):
    with open(filepath, 'r') as f:
        try:
            config = json.load(f)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON configuration: {e}")
    return config


def validate_parameters(params):
    # Check that time step and simulation time are positive
    dt = params.get('dt', 1)
    simulation_time = params.get('simulation_time', 1000)
    if dt <= 0 or simulation_time <= 0:
        raise ValueError('Time step and simulation time must be positive.')

    # Validate gravitational constant
    G = params.get('G', 6.67430e-11)
    if G <= 0:
        raise ValueError('Gravitational constant must be positive.')

    # Validate bodies
    bodies = params.get('bodies', [])
    if len(bodies) < 2:
        raise ValueError('At least two bodies are required for the simulation.')

    positions = []
    for body in bodies:
        pos = body.get('position', None)
        if pos is None or len(pos) != 2:
            raise ValueError('Each body must have a valid 2D position.')
        positions.append(tuple(pos))

    # Check for overlapping positions (simple check)
    if len(positions) != len(set(positions)):
        raise ValueError('Two or more bodies have overlapping initial positions.')

    # Additional validations can be added as needed
    return True
