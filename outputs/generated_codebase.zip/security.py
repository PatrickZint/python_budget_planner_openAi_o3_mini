import os
from dotenv import load_dotenv


def load_secure_config():
    """Load configuration settings securely using environment variables."""
    # Load environment variables from a .env file if present
    load_dotenv()
    config = {
        'time_step': float(os.getenv('TIME_STEP', '0.01')),
        'total_time': float(os.getenv('TOTAL_TIME', '10')),
        'integration_method': os.getenv('INTEGRATION_METHOD', 'RK4'),
        'collision_mode': os.getenv('COLLISION_MODE', 'merge'),
        'log_interval': float(os.getenv('LOG_INTERVAL', '0.1')),
        'export_csv': os.getenv('EXPORT_CSV', 'simulation.csv'),
        'export_hdf5': os.getenv('EXPORT_HDF5', 'simulation.h5')
    }
    return config
