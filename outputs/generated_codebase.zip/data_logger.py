import csv
import logging


class DataLogger:
    def __init__(self, logging_frequency=1, output_file='simulation_log.csv'):
        self.logging_frequency = logging_frequency
        self.output_file = output_file
        self.setup_logger()
        # Open CSV file for writing
        self.csv_file = open(self.output_file, 'w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        # Write header row
        self.csv_writer.writerow(['time', 'body_index', 'mass', 'position_x', 'position_y', 'velocity_x', 'velocity_y'])

    def setup_logger(self):
        self.logger = logging.getLogger('OrbitalSimulator')
        self.logger.setLevel(logging.DEBUG)
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

    def log_simulation_state(self, timestamp, state):
        # Log to console
        self.logger.info(f"Time: {timestamp:.2f} seconds")
        for idx, body in enumerate(state):
            pos = body['position']
            vel = body['velocity']
            self.logger.info(f"Body {idx}: Mass={body['mass']}, Position=({pos[0]:.2f}, {pos[1]:.2f}), Velocity=({vel[0]:.2f}, {vel[1]:.2f})")
            # Write to CSV
            self.csv_writer.writerow([
                timestamp,
                idx,
                body['mass'],
                pos[0],
                pos[1],
                vel[0],
                vel[1]
            ])

    def __del__(self):
        try:
            self.csv_file.close()
        except Exception:
            pass
