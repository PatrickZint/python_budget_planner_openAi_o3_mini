import numpy as np

# Minimum distance to avoid singularity
MIN_DISTANCE = 1e-2

class CelestialBody:
    def __init__(self, mass, position, velocity):
        self.mass = mass
        self.position = position  # Expected to be a numpy array with 2 elements
        self.velocity = velocity  # Expected to be a numpy array with 2 elements

    def __repr__(self):
        return f"CelestialBody(mass={self.mass}, pos={self.position}, vel={self.velocity})"


def calculate_gravitational_force(body1, body2, G):
    # Vector from body1 to body2
    r_vec = body2.position - body1.position
    r_mag = np.linalg.norm(r_vec)
    # Safeguard against division by zero
    if r_mag < MIN_DISTANCE:
        r_mag = MIN_DISTANCE
    # Unit vector in the direction of the force
    r_hat = r_vec / r_mag
    # Newton's law of gravitation
    force_mag = G * body1.mass * body2.mass / (r_mag ** 2)
    force = force_mag * r_hat
    return force


def update_positions(bodies, dt, G, method='euler'):
    # For now, only Euler integration is implemented
    if method.lower() != 'euler':
        raise NotImplementedError(f"Integration method '{method}' is not implemented yet.")

    # Compute forces for each pair (assuming two-body simulation for simplicity).
    # For a general n-body simulation, one would compute net forces
    n = len(bodies)
    forces = [np.zeros(2) for _ in range(n)]

    # Calculate mutual gravitational forces
    for i in range(n):
        for j in range(i + 1, n):
            force = calculate_gravitational_force(bodies[i], bodies[j], G)
            forces[i] += force
            forces[j] -= force  # Newton's third law

    # Update velocities and positions using Euler's method
    for i, body in enumerate(bodies):
        # a = F/m
        acceleration = forces[i] / body.mass
        # Update velocity
        body.velocity += acceleration * dt
        # Update position
        body.position += body.velocity * dt


def set_integration_method(method):
    # Future extension: change the integration method used
    # For now, only Euler is supported
    if method.lower() != 'euler':
        raise NotImplementedError(f"Integration method '{method}' is not available yet.")
    return method
