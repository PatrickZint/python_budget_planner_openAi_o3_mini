import numpy as np

# Gravitational constant (in SI units, if using realistic scaling)
G = 6.67430e-11


class Body:
    def __init__(self, mass, radius, position, velocity):
        self.mass = mass
        self.radius = radius
        self.position = position.astype(float)
        self.velocity = velocity.astype(float)


def compute_acceleration(bodies, index):
    """Compute net gravitational acceleration on a body at index from all other bodies."""
    body = bodies[index]
    acceleration = np.zeros(3)
    for j, other in enumerate(bodies):
        if index != j:
            r_vec = other.position - body.position
            # Add a small epsilon to avoid division by zero
            distance = np.linalg.norm(r_vec) + 1e-10
            # Newtonian gravitation
            a = G * other.mass / (distance**3) * r_vec
            acceleration += a
    return acceleration


def integrate_rk4(bodies, dt):
    """Integrate bodies' motion using the fourth-order Runge-Kutta method."""
    num_bodies = len(bodies)
    positions = [body.position.copy() for body in bodies]
    velocities = [body.velocity.copy() for body in bodies]

    # k1
    k1_v = [compute_acceleration(bodies, i) * dt for i in range(num_bodies)]
    k1_x = [vel * dt for vel in velocities]

    # k2
    for i, body in enumerate(bodies):
        body.position = positions[i] + 0.5 * k1_x[i]
        body.velocity = velocities[i] + 0.5 * k1_v[i]
    k2_v = [compute_acceleration(bodies, i) * dt for i in range(num_bodies)]
    k2_x = [body.velocity * dt for body in bodies]

    # k3
    for i, body in enumerate(bodies):
        body.position = positions[i] + 0.5 * k2_x[i]
        body.velocity = velocities[i] + 0.5 * k2_v[i]
    k3_v = [compute_acceleration(bodies, i) * dt for i in range(num_bodies)]
    k3_x = [body.velocity * dt for body in bodies]

    # k4
    for i, body in enumerate(bodies):
        body.position = positions[i] + k3_x[i]
        body.velocity = velocities[i] + k3_v[i]
    k4_v = [compute_acceleration(bodies, i) * dt for i in range(num_bodies)]
    k4_x = [body.velocity * dt for body in bodies]

    # Combine increments
    for i, body in enumerate(bodies):
        body.position = positions[i] + (k1_x[i] + 2*k2_x[i] + 2*k3_x[i] + k4_x[i]) / 6
        body.velocity = velocities[i] + (k1_v[i] + 2*k2_v[i] + 2*k3_v[i] + k4_v[i]) / 6


def integrate_verlet(bodies, dt):
    """Integrate bodies' motion using the Verlet integration method."""
    num_bodies = len(bodies)
    # Compute current accelerations for all bodies
    accelerations = [compute_acceleration(bodies, i) for i in range(num_bodies)]

    # Update positions
    for i, body in enumerate(bodies):
        body.position += body.velocity * dt + 0.5 * accelerations[i] * dt * dt

    # Compute new accelerations after position update
    new_accelerations = [compute_acceleration(bodies, i) for i in range(num_bodies)]

    # Update velocities
    for i, body in enumerate(bodies):
        body.velocity += 0.5 * (accelerations[i] + new_accelerations[i]) * dt
