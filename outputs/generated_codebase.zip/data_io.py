import json
import csv
import argparse
import logging


def setup_logger(verbosity=logging.INFO):
    logger = logging.getLogger('OrbitalSimulator')
    logger.setLevel(verbosity)
    if not logger.handlers:
        ch = logging.StreamHandler()
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        logger.addHandler(ch)
    return logger


def parse_config_file(config_path):
    """
    Parse a JSON configuration file and return a dictionary of parameters.
    """
    with open(config_path, 'r') as f:
        config = json.load(f)
    return config


def export_data_csv(filename, simulation_data):
    """
    Export simulation data to a CSV file. This example writes time and positions of both bodies.
    """
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = ['time', 'body1_x', 'body1_y', 'body2_x', 'body2_y']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for state in simulation_data:
            row = {
                'time': state['time'],
                'body1_x': state['body1']['pos'][0],
                'body1_y': state['body1']['pos'][1],
                'body2_x': state['body2']['pos'][0],
                'body2_y': state['body2']['pos'][1]
            }
            writer.writerow(row)


def export_data_json(filename, simulation_data):
    """
    Export simulation data to a JSON file.
    """
    with open(filename, 'w') as f:
        json.dump(simulation_data, f, indent=4)


def get_command_line_args():
    parser = argparse.ArgumentParser(description='2D Orbital Simulator')
    parser.add_argument('-c', '--config', help='Path to configuration JSON file', required=True)
    parser.add_argument('--export_csv', help='Path to export CSV file', default=None)
    parser.add_argument('--export_json', help='Path to export JSON file', default=None)
    parser.add_argument('--verbose', help='Verbose output', action='store_true')
    parser.add_argument('--visualize', help='Enable visualization', action='store_true')
    return parser.parse_args()
