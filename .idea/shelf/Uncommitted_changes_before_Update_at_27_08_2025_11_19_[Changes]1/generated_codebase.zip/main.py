import tkinter as tk
from controller import NewsController


def main():
    root = tk.Tk()
    root.title("Lightweight News Reader")
    # Set minimum size for better UI experience
    root.minsize(500, 400)
    app = NewsController(root)
    root.mainloop()


if __name__ == "__main__":
    main()
