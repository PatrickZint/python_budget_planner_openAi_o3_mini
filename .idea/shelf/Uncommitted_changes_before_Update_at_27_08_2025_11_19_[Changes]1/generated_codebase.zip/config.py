import configparser
import os
from encryption_helper import decrypt_data


def load_config():
    config = configparser.ConfigParser()
    config.read("config.ini")
    return config


def get_api_key():
    # Load API configuration from config.ini
    config = load_config()
    encrypted_key = config.get("API", "encrypted_key", fallback=None)
    if not encrypted_key:
        raise Exception("API key not configured in config.ini!")
    
    # Get the decryption key from an environment variable for security
    decryption_key = os.getenv("DECRYPTION_KEY")
    if not decryption_key:
        raise Exception("Decryption key not set in environment variable DECRYPTION_KEY!")
    
    # Decrypt the API key before use
    return decrypt_data(encrypted_key, decryption_key)
