from cryptography.fernet import Fernet


def encrypt_data(data, key):
    """
    Encrypt the provided data using the given key.
    Returns the encrypted string.
    """
    fernet = Fernet(key)
    return fernet.encrypt(data.encode()).decode()


def decrypt_data(encrypted_data, key):
    """
    Decrypt the provided encrypted_data using the given key.
    Returns the decrypted string.
    """
    fernet = Fernet(key)
    return fernet.decrypt(encrypted_data.encode()).decode()
