import threading
from api_handler import get_top_headlines
from models import parse_headlines
from view import NewsView


class NewsController:
    def __init__(self, root):
        self.root = root
        self.view = NewsView(root, self)
        self.headlines = []
        self.refresh_headlines()

    def refresh_headlines(self):
        self.view.show_loading(True)
        # Use a thread to fetch headlines so the UI remains responsive
        threading.Thread(target=self.fetch_headlines, daemon=True).start()

    def fetch_headlines(self):
        json_data = get_top_headlines()
        if json_data is not None:
            self.headlines = parse_headlines(json_data)
            self.root.after(0, self.update_view)
        else:
            self.root.after(0, lambda: self.view.display_error("Unable to retrieve news. Please try again later."))

    def update_view(self):
        self.view.update_headlines(self.headlines)
        self.view.show_loading(False)

    def on_headline_selected(self, event):
        widget = event.widget
        selection = widget.curselection()
        if selection:
            index = selection[0]
            headline = self.headlines[index]
            self.view.show_detail(headline)
