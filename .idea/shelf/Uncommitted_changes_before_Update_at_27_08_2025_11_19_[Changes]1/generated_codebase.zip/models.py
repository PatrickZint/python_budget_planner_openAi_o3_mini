from dataclasses import dataclass
from typing import Optional


@dataclass
class Headline:
    title: str
    description: Optional[str]
    published_at: str
    source: str
    url: str
    url_to_image: Optional[str] = None


def parse_headlines(json_data):
    """
    Parse JSON data from the news API into a list of Headline objects.
    """
    headlines = []
    if json_data and "articles" in json_data:
        for article in json_data["articles"]:
            headline = Headline(
                title=article.get("title", "No Title"),
                description=article.get("description", ""),
                published_at=article.get("publishedAt", ""),
                source=article.get("source", {}).get("name", "Unknown Source"),
                url=article.get("url", ""),
                url_to_image=article.get("urlToImage")
            )
            headlines.append(headline)
    return headlines
