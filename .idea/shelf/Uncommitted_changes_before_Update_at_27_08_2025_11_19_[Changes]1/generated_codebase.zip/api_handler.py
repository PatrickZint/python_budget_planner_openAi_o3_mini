import requests
import time
from config import get_api_key


BASE_URL = "https://newsapi.org/v2/top-headlines"
COUNTRY = "us"


def get_top_headlines():
    """
    Fetch top headlines from the news API.
    Implements simple retry logic for intermittent network issues.
    Returns the parsed JSON response if successful, otherwise None.
    """
    api_key = get_api_key()
    params = {
        "country": COUNTRY,
        "apiKey": api_key
    }
    retries = 3
    for attempt in range(retries):
        try:
            response = requests.get(BASE_URL, params=params, timeout=5)
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error: HTTP {response.status_code} encountered on attempt {attempt + 1}")
        except requests.RequestException as e:
            print(f"Request failed on attempt {attempt + 1}: {e}")
        time.sleep(1)  # Simple back-off
    return None
