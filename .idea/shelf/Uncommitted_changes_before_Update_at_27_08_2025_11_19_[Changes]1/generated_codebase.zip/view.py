import tkinter as tk
from tkinter import ttk
import webbrowser


class NewsView(tk.Frame):
    def __init__(self, master, controller):
        super().__init__(master)
        self.controller = controller
        self.pack(fill="both", expand=True)
        self.create_widgets()

    def create_widgets(self):
        # Home screen frame
        self.home_frame = tk.Frame(self)
        self.home_frame.pack(fill='both', expand=True)

        self.refresh_button = tk.Button(self.home_frame, text="Refresh", command=self.controller.refresh_headlines)
        self.refresh_button.pack(pady=5)

        self.headlines_listbox = tk.Listbox(self.home_frame)
        self.headlines_listbox.pack(fill='both', expand=True, padx=10, pady=10)
        self.headlines_listbox.bind('<<ListboxSelect>>', self.controller.on_headline_selected)

        self.loading_label = tk.Label(self.home_frame, text="")
        self.loading_label.pack()

        # Detailed view frame
        self.detail_frame = tk.Frame(self)

        self.title_label = tk.Label(self.detail_frame, text="", font=("Helvetica", 16, "bold"), wraplength=400)
        self.title_label.pack(pady=10)

        self.description_label = tk.Label(self.detail_frame, text="", wraplength=400, justify="left")
        self.description_label.pack(pady=10)

        self.info_label = tk.Label(self.detail_frame, text="", font=("Helvetica", 10, "italic"))
        self.info_label.pack(pady=5)

        self.open_link_button = tk.Button(self.detail_frame, text="Open in Browser", command=self.open_article)
        self.open_link_button.pack(pady=5)

        self.back_button = tk.Button(self.detail_frame, text="Back", command=self.show_home)
        self.back_button.pack(pady=5)

    def update_headlines(self, headlines):
        self.headlines_listbox.delete(0, tk.END)
        self.headlines_data = headlines  # Store Headline objects for later retrieval
        for headline in headlines:
            display_text = f"{headline.title} ({headline.published_at})"
            self.headlines_listbox.insert(tk.END, display_text)

    def show_loading(self, loading=True):
        if loading:
            self.loading_label.config(text="Loading...")
        else:
            self.loading_label.config(text="")

    def show_home(self):
        self.detail_frame.pack_forget()
        self.home_frame.pack(fill="both", expand=True)

    def show_detail(self, headline):
        self.home_frame.pack_forget()
        self.detail_frame.pack(fill="both", expand=True)
        self.title_label.config(text=headline.title)
        self.description_label.config(text=headline.description or "No Description Available")
        info_text = f"Source: {headline.source} | Published At: {headline.published_at}"
        self.info_label.config(text=info_text)
        self.current_article_url = headline.url

    def open_article(self):
        if hasattr(self, "current_article_url") and self.current_article_url:
            webbrowser.open(self.current_article_url)

    def display_error(self, message):
        self.loading_label.config(text=message)
